/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.aurora.scheduler.base;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.twitter.common.testing.easymock.EasyMockTest;

import org.easymock.EasyMock;
import org.easymock.IAnswer;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.contains;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.expectLastCall;

public class AsyncUtilTest extends EasyMockTest {
  private Logger logger;
  private ScheduledThreadPoolExecutor executor;
  private CountDownLatch latch;

  @Before
  public void setUp() {
    logger = createMock(Logger.class);
    latch = new CountDownLatch(1);
    executor = AsyncUtil.singleThreadLoggingScheduledExecutor("Test-%d", logger);
  }

  @Test
  public void testScheduleLogging() throws Exception {
    logger.log(
        eq(Level.SEVERE),
        contains("Expected exception."),
        EasyMock.<ExecutionException>anyObject());

    expectLastCall().andAnswer(new IAnswer<Object>() {
      @Override
      public Object answer() throws Throwable {
        latch.countDown();
        return null;
      }
    }).once();

    control.replay();

    executor.schedule(new Runnable() {
      @Override
      public void run() {
        throw new IllegalArgumentException("Expected exception.");
      }
    }, 0, TimeUnit.MILLISECONDS);

    latch.await();
  }

  @Test
  public void testSubmitLogging() throws Exception {
    logger.log(
        eq(Level.SEVERE),
        contains("Expected exception."),
        EasyMock.<ExecutionException>anyObject());

    expectLastCall().andAnswer(new IAnswer<Object>() {
      @Override
      public Object answer() throws Throwable {
        latch.countDown();
        return null;
      }
    }).once();

    control.replay();

    executor.submit(new Runnable() {
      @Override
      public void run() {
        throw new IllegalArgumentException("Expected exception.");
      }
    });

    latch.await();
  }
}
